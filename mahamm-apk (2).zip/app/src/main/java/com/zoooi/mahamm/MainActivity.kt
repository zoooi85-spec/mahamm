package com.zoooi.mahamm

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView

    // نسخ النص عن طريق أندرويد (لزر نسخ المواعيد)
    private val shim = """
(function(){
  try{
    var w = function(t){ try{ AndroidBridge.copy(String(t)); return Promise.resolve(); }catch(e){ return Promise.reject(e); } };
    if(!navigator.clipboard){ Object.defineProperty(navigator,'clipboard',{value:{writeText:w}}); }
    else { try{ navigator.clipboard.writeText = w; }catch(e){ Object.defineProperty(navigator,'clipboard',{value:{writeText:w}}); } }
  }catch(e){}
  try{
    if(!window.__mhHook){ window.__mhHook=1;
      var o=Storage.prototype.setItem;
      Storage.prototype.setItem=function(k,v){ o.call(this,k,v); if(k==='colornotes_v1'){ try{ AndroidBridge.saveNotes(String(v)); }catch(e){} } };
    }
    AndroidBridge.saveNotes(localStorage.getItem('colornotes_v1')||'[]');
  }catch(e){}
})();
"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val bg = Color.parseColor(if (night) "#121212" else "#FFFFFF")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (!night && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.textZoom = 100

        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript(shim, null)
            }
        }

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("file:///android_asset/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // زر الرجوع: يقفل الملاحظة أو السمات أولاً، وبعدها يطلع من التطبيق
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val js = """
(function(){
  var s=document.getElementById('sheet');
  if(s && !s.hidden){ document.getElementById('back').click(); return 'y'; }
  var k=document.getElementById('skinSheet');
  if(k && !k.hidden){ document.getElementById('skinClose').click(); return 'y'; }
  return 'n';
})()
"""
        web.evaluateJavascript(js) { r ->
            if (r == null || !r.contains("y")) finish()
        }
    }

    override fun onPause() {
        super.onPause()
        CountdownWidget.updateAll(this)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveNotes(json: String) {
            getSharedPreferences("mahamm", Context.MODE_PRIVATE).edit().putString("notes", json).apply()
            CountdownWidget.updateAll(applicationContext)
        }

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("مهام", text))
            }
        }
    }
}
