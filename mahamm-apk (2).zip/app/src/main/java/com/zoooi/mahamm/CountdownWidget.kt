package com.zoooi.mahamm

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class CountdownWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_BOOT_COMPLETED -> updateAll(ctx)
        }
    }

    companion object {
        private val ROWS = intArrayOf(R.id.r0, R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5)
        private val DAYS = arrayOf("الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد")

        fun updateAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, CountdownWidget::class.java))
                if (ids.isEmpty()) return
                val v = build(ctx)
                for (id in ids) mgr.updateAppWidget(id, v)
            } catch (e: Exception) { }
        }

        // أرقام عربية مثل ٣ و١٧
        private fun ar(n: Long): String {
            val d = "٠١٢٣٤٥٦٧٨٩"
            return n.toString().map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
        }

        private fun countdown(t: LocalDate, d: LocalDate): String {
            val n = ChronoUnit.DAYS.between(t, d)
            if (n <= 0L) return if (n == 0L) "اليوم" else ""
            if (n == 1L) return "بكرة"
            if (n == 2L) return "بعد يومين"
            if (n < 30L) return "بعد " + ar(n) + (if (n <= 10L) " أيام" else " يوم")
            var m = ((d.year - t.year) * 12 + (d.monthValue - t.monthValue)).toLong()
            if (d.dayOfMonth < t.dayOfMonth) m--
            val base = t.plusMonths(m)
            val r = ChronoUnit.DAYS.between(base, d)
            val ms = when {
                m == 1L -> "شهر واحد"
                m == 2L -> "شهرين"
                m <= 10L -> ar(m) + " أشهر"
                else -> ar(m) + " شهر"
            }
            val rs = when {
                r <= 0L -> ""
                r == 1L -> " ويوم"
                r == 2L -> " ويومين"
                else -> " و" + ar(r) + (if (r <= 10L) " أيام" else " يوم")
            }
            return "بعد " + ms + rs
        }

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_countdown)
            val today = LocalDate.now()
            val lines = ArrayList<String>()
            try {
                val raw = ctx.getSharedPreferences("mahamm", Context.MODE_PRIVATE).getString("notes", "[]") ?: "[]"
                val arr = JSONArray(raw)
                val items = ArrayList<Triple<LocalDate, String, String>>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val ds = o.optString("date", "")
                    if (ds.length < 10) continue
                    val d = try { LocalDate.parse(ds.substring(0, 10)) } catch (e: Exception) { continue }
                    if (d.isBefore(today)) continue
                    val emoji = o.optString("emoji", "").ifBlank { "📌" }
                    val title = o.optString("title", "").ifBlank { "بدون عنوان" }
                    val line = emoji + " " + title + " - " + DAYS[d.dayOfWeek.value - 1] + " " + countdown(today, d)
                    items.add(Triple(d, o.optString("time", "99:99"), line))
                }
                items.sortWith(compareBy({ it.first }, { it.second }))
                for (x in items.take(ROWS.size)) lines.add(x.third)
            } catch (e: Exception) { }

            for ((i, id) in ROWS.withIndex()) {
                if (i < lines.size) {
                    v.setTextViewText(id, lines[i])
                    v.setViewVisibility(id, View.VISIBLE)
                } else v.setViewVisibility(id, View.GONE)
            }
            v.setViewVisibility(R.id.empty, if (lines.isEmpty()) View.VISIBLE else View.GONE)

            val open = Intent(ctx, MainActivity::class.java)
            val pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.root, pi)
            return v
        }
    }
}
