package com.zoooi.mahamm

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray

class ShopWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    companion object {
        private val ROWS = intArrayOf(R.id.s0, R.id.s1, R.id.s2, R.id.s3, R.id.s4, R.id.s5, R.id.s6)
        // نفس أقسام التطبيق وبنفس الترتيب
        private val CATS = arrayOf(
            arrayOf("drinks", "🥤", "مشروبات"),
            arrayOf("dairy", "🧀", "ألبان وأجبان"),
            arrayOf("veg", "🥬", "خضار"),
            arrayOf("fruit", "🍎", "فواكه"),
            arrayOf("meat", "🍗", "لحوم ودواجن"),
            arrayOf("bakery", "🍞", "مخبوزات وحبوب"),
            arrayOf("sweets", "🍫", "حلويات وسناكات"),
            arrayOf("clean", "🧴", "منظفات"),
            arrayOf("other", "🛒", "أخرى")
        )

        private fun ar(n: Int): String {
            val d = "٠١٢٣٤٥٦٧٨٩"
            return n.toString().map { if (it in '0'..'9') d[it - '0'] else it }.joinToString("")
        }

        fun updateAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, ShopWidget::class.java))
                if (ids.isEmpty()) return
                val v = build(ctx)
                for (id in ids) mgr.updateAppWidget(id, v)
            } catch (e: Exception) { }
        }

        fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_shop)
            val lines = ArrayList<String>()
            var left = 0
            try {
                val raw = ctx.getSharedPreferences("mahamm", Context.MODE_PRIVATE).getString("shop", "[]") ?: "[]"
                val arr = JSONArray(raw)
                val byCat = LinkedHashMap<String, ArrayList<String>>()
                for (c in CATS) byCat[c[0]] = ArrayList()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optBoolean("done", false)) continue
                    val t = o.optString("title", "").trim()
                    if (t.isEmpty()) continue
                    val q = o.optString("qty", "").trim()
                    var cat = o.optString("cat", "other")
                    if (!byCat.containsKey(cat)) cat = "other"
                    byCat[cat]!!.add(if (q.isEmpty()) t else "$t ($q)")
                    left++
                }
                for (c in CATS) {
                    val items = byCat[c[0]]!!
                    if (items.isEmpty()) continue
                    lines.add(c[1] + " " + c[2] + ": " + items.joinToString("، "))
                }
            } catch (e: Exception) { }

            v.setTextViewText(R.id.shopTitle,
                if (left > 0) "🛒 قائمة التسوق · باقي " + ar(left) else "🛒 قائمة التسوق")
            for ((i, id) in ROWS.withIndex()) {
                if (i < lines.size) {
                    v.setTextViewText(id, lines[i])
                    v.setViewVisibility(id, View.VISIBLE)
                } else v.setViewVisibility(id, View.GONE)
            }
            v.setViewVisibility(R.id.shopEmpty, if (lines.isEmpty()) View.VISIBLE else View.GONE)

            val open = Intent(ctx, MainActivity::class.java).putExtra("tab", "shop")
            val pi = PendingIntent.getActivity(ctx, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.shopRoot, pi)
            return v
        }
    }
}
